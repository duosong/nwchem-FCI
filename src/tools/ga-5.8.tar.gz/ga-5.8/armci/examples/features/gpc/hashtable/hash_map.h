/** @file
 * $Id:
 * header to include STL's hash_map
 */
#include <ext/hash_map>
#ifndef STL_HASHMAP_NAMESPACE
#   define STL_HASHMAP_NAMESPACE __gnu_cxx
#endif
