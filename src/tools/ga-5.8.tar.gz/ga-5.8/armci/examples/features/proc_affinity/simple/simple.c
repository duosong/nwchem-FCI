#if HAVE_CONFIG_H
#   include "config.h"
#endif

/* $Id$ */
int main(int argc, char **argv)
{
    return 0;
}
